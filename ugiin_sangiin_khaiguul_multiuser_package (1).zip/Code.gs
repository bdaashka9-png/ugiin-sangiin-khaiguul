// Google Apps Script — Үгийн сангийн нууц хайгуул
// Extensions > Apps Script хэсэгт энэ кодыг байршуулна.
const SHEET_NAME = "Үр дүн";
const PROP_PIN = "TEACHER_PIN";

function doGet(e) {
  return ContentService.createTextOutput(JSON.stringify({ok:true, message:"Үгийн сангийн квестийн сервер ажиллаж байна."}))
    .setMimeType(ContentService.MimeType.JSON);
}
function doPost(e) {
  try {
    const data = JSON.parse((e.postData && e.postData.contents) || "{}");
    const action = (e.parameter && e.parameter.action) || data.action || "save";
    if (action === "save") return json_(saveResult_(data));
    if (action === "results") {
      const pin = (e.parameter && e.parameter.pin) || data.pin || "";
      const expected = PropertiesService.getScriptProperties().getProperty(PROP_PIN);
      if (!expected || pin !== expected) return json_({ok:false,error:"Багшийн PIN буруу байна."});
      return json_({ok:true,rows:getResults_()});
    }
    return json_({ok:false,error:"Тодорхойгүй хүсэлт."});
  } catch(err) { return json_({ok:false,error:String(err)}); }
}
function sheet_() {
  const props=PropertiesService.getScriptProperties();
  let id=props.getProperty("SPREADSHEET_ID");
  let ss=id?SpreadsheetApp.openById(id):SpreadsheetApp.create("Үгийн сангийн нууц хайгуул — Сурагчдын үр дүн");
  if(!id) props.setProperty("SPREADSHEET_ID",ss.getId());
  let sh=ss.getSheetByName(SHEET_NAME)||ss.insertSheet(SHEET_NAME);
  if(sh.getLastRow()===0) sh.appendRow(["Цаг","Сурагч","Анги","Өртөө","Оноо","Түвшин","Хариулт"]);
  return sh;
}
function saveResult_(d) {
  if(!d.name||!d.classCode||!d.station) throw new Error("Нэр, анги, өртөө дутуу байна.");
  const sh=sheet_(), rows=sh.getDataRange().getValues();
  // Нэг сурагчийн нэг өртөөний хамгийн өндөр оноог хадгална.
  let found=-1;
  for(let i=1;i<rows.length;i++) if(String(rows[i][1]).toLowerCase()===String(d.name).toLowerCase() && String(rows[i][2]).toLowerCase()===String(d.classCode).toLowerCase() && Number(rows[i][3])===Number(d.station)){found=i+1;break;}
  const row=[new Date(),String(d.name),String(d.classCode),Number(d.station),Number(d.points)||0,Number(d.level)||1,String(d.answer||"").slice(0,5000)];
  if(found>0){let old=Number(sh.getRange(found,5).getValue())||0;if(row[4]>=old)sh.getRange(found,1,1,row.length).setValues([row]);}
  else sh.appendRow(row);
  return {ok:true};
}
function getResults_() {
  const sh=sheet_(), vals=sh.getDataRange().getValues(), map={};
  for(let i=1;i<vals.length;i++){
    const r=vals[i],key=String(r[2])+"||"+String(r[1]);
    if(!map[key])map[key]={name:r[1],classCode:r[2],stations:{},score:0,updated:r[0]};
    const s=map[key];s.stations[r[3]]=Number(r[4])||0;
    s.score=Object.values(s.stations).reduce((a,b)=>a+b,0);
    s.updated=r[0];
  }
  return Object.values(map).map(x=>({name:x.name,classCode:x.classCode,completed:Object.keys(x.stations).length,score:x.score,updated:x.updated instanceof Date?Utilities.formatDate(x.updated,Session.getScriptTimeZone(),"yyyy-MM-dd HH:mm"):String(x.updated)}))
    .sort((a,b)=>b.score-a.score);
}
function json_(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
